`avg delay showed in asm tutorial is not the same as output, so manually calculated avg delay is shown here`
 ```
total sent : 14933753
total recv : 15076289
total delay: 142536
avg delay  : 142536/9 = 15837
```
```
sent
mins       secs        millisecs
21         45          638
22         29          232
22         33          192
22         48          098
25         58          509
27         15          467
32         45          088
36         39          262
36         39          267
14580000   351000      2753           14933753
```
```
recv
mins       secs        millisecs
22         11          936
22         29          256
22         48          075
22         52          034
26         42          425
27         42          030
33         11          934
36         39          267
36         39          332
14760000   313000      3289           15076289
```