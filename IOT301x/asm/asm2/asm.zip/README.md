Assignment 2 - Xử lý bản tin dữ liệu cảm biến lưu trữ tại bộ điều khiển trung tâm

Yêu cầu: 
- Bắt buộc: 3/3
- Nâng cao: 2/3

Sử dụng phần lớn các function liên quan tới string, pointer để chỉ địa chỉ và thay đổi các phần tử array.
Các hàm hỗ trợ lần nhau sử dụng biến global và các địa chỉ biến.