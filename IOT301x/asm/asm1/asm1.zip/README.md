- must compile with sqrt >= 2.0: https://stackoverflow.com/questions/3533594/sqrt-function-not-working-with-variable-arguments
- `eg "gcc tamgiac_*nix.c -lm"`

Assignment 1 - Lập trình giải hình tam giác

Yêu cầu: 
- Bắt buộc: 5/5
- Nâng cao: 3/

Sử dụng kiến thức toán cơ bản.
Phần lớn các vòng lặp dùng để kiểm tra hình dạng tam giác.